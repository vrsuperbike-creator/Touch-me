package com.luckytouch.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    int total = 5, index = 0;
    ArrayList<Integer> numbers = new ArrayList<>();
    TextView result, progress, pad;
    EditText countInput;
    LinearLayout root;

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    void startDraw() {
        String s = countInput.getText().toString().trim();
        try { total = Integer.parseInt(s); }
        catch (Exception e) { total = 5; }
        if (total < 2 || total > 100) {
            Toast.makeText(this, "২ থেকে ১০০ জনের মধ্যে সংখ্যা দিন", Toast.LENGTH_SHORT).show();
            return;
        }
        numbers.clear();
        for (int i = 1; i <= total; i++) numbers.add(i);
        Collections.shuffle(numbers);
        index = 0;
        result.setText("?");
        progress.setText("0 / " + total + " জনের নম্বর প্রকাশিত");
        pad.setText("টাচ করুন");
    }

    void reveal() {
        if (index >= total) {
            Toast.makeText(this, "সবাই নম্বর পেয়ে গেছেন! আবার শুরু করুন।", Toast.LENGTH_SHORT).show();
            return;
        }
        int number = numbers.get(index++);
        result.setText(String.valueOf(number));
        progress.setText(index + " / " + total + " জনের নম্বর প্রকাশিত");
        pad.setText(index == total ? "সব নম্বর প্রকাশিত" : "পরের জনের জন্য টাচ করুন");
        if (index == total) {
            StringBuilder all = new StringBuilder("চূড়ান্ত ক্রম: ");
            for (int i = 0; i < numbers.size(); i++) {
                if (i > 0) all.append("  •  ");
                all.append(numbers.get(i));
            }
            Toast.makeText(this, all.toString(), Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(246, 248, 255));

        TextView title = text("LUCKY TOUCH", 28, Color.rgb(40, 55, 110));
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));

        TextView subtitle = text("র‍্যান্ডম ড্র — কে আগে যাবে?", 16, Color.DKGRAY);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView label = text("অংশগ্রহণকারীর সংখ্যা (২–১০০)", 15, Color.DKGRAY);
        root.addView(label, new LinearLayout.LayoutParams(-1, dp(38)));

        countInput = new EditText(this);
        countInput.setText("5");
        countInput.setInputType(2);
        countInput.setGravity(Gravity.CENTER);
        countInput.setTextSize(20);
        root.addView(countInput, new LinearLayout.LayoutParams(-1, dp(52)));

        Button begin = new Button(this);
        begin.setText("নতুন ড্র শুরু করুন");
        root.addView(begin, new LinearLayout.LayoutParams(-1, dp(54)));

        result = text("?", 76, Color.rgb(40, 85, 190));
        result.setTypeface(null, Typeface.BOLD);
        root.addView(result, new LinearLayout.LayoutParams(-1, dp(150)));

        pad = text("টাচ করুন", 22, Color.WHITE);
        pad.setTypeface(null, Typeface.BOLD);
        pad.setBackgroundColor(Color.rgb(45, 100, 220));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(110));
        pp.setMargins(0, dp(12), 0, dp(12));
        root.addView(pad, pp);
        pad.setOnClickListener(v -> reveal());

        progress = text("0 / 5 জনের নম্বর প্রকাশিত", 16, Color.DKGRAY);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView note = text("প্রতিটি টাচে একটি করে আলাদা নম্বর প্রকাশ হবে।", 13, Color.GRAY);
        root.addView(note, new LinearLayout.LayoutParams(-1, dp(48)));

        begin.setOnClickListener(v -> startDraw());
        setContentView(root);
        startDraw();
    }
}
